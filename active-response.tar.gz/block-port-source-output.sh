#!/bin/bash
read -r json
dest_ip=$(python3 -c 'import json, sys; print( json.load(sys.stdin)["parameters"]["alert"]["data"]["dest_ip"] )' <<< "$json")
source_port=$(python3 -c 'import json, sys; print( json.load(sys.stdin)["parameters"]["alert"]["data"]["src_port"] )' <<< "$json")
proto=$(python3 -c 'import json, sys; print( json.load(sys.stdin)["parameters"]["alert"]["data"]["proto"] )' <<< "$json")


if [[ $dest_ip =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    iptables -A OUTPUT -p $proto --sport $source_port -j DROP
elif [[ $dest_ip =~ ^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$ ]]; then
    ip6tables -A OUTPUT -p $proto --sport $source_port -j DROP
fi
